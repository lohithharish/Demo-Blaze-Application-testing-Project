# 📅 Changelog

All notable changes to the **DemoBlaze QA Testing Project** are documented in
this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [Unreleased]

### Planned — Phase 2 (Automation)
- Selenium / Cypress automation framework setup
- Page Object Model (POM) implementation
- Automated smoke test suite (P0 critical paths)
- Full regression test suite automation
- CI/CD pipeline via GitHub Actions
- API test suite (Postman / RestAssured)
- Performance baseline tests (JMeter / k6)
- Allure / Extent Reports integration

---

## [1.0.0] — 2026-03-07

### Added — Phase 1: Manual Testing (Initial Release)

#### 📋 Documentation
- `README.md` — Full project overview with badges, module breakdown, and automation roadmap
- `Test_Plan.docx` — Comprehensive 14-section test plan document
- `Test_Strategy.docx` — 15-section overarching QA strategy document
- `Requirement_Scope.md` — 145 requirements (107 FR + 38 NFR) with full RTM
- `CONTRIBUTING.md` — Contribution guidelines and test case standards
- `CODE_OF_CONDUCT.md` — Community standards and enforcement policy
- `SECURITY.md` — Security disclosure policy and test data notice
- `CHANGELOG.md` — This file
- `LICENSE` — MIT License

#### 🧪 Test Scenarios
- `DemoBlaze_Test_Scenarios.xlsx` — 20 test scenarios across all modules (TS_001–TS_020)

#### 📝 Test Cases (1,000+ total across 12 modules)
- `Signup_Test_Cases.xlsx` — ~50 test cases · TS_001
- `Login_Test_Cases.xlsx` — ~63 test cases · TS_002
- `Logout_Test_Cases_Updated.xlsx` — ~70 test cases · TS_003
- `HomePage_Test_Cases_Updated.xlsx` — ~79 test cases · TS_004, TS_005, TS_010, TS_011
- `Contact_Test_Cases_Updated.xlsx` — ~90 test cases · TS_006, TS_007
- `ProductCategories_Test_Cases_Updated.xlsx` — ~79 test cases · TS_008
- `ProductDetails_Test_Cases_Updated.xlsx` — ~89 test cases · TS_009
- `Cart_Test_Cases_Updated.xlsx` — ~99 test cases · TS_012
- `PlaceOrder_Test_Cases_Updated.xlsx` — ~114 test cases · TS_013, TS_019
- `OrderConfirmation_Test_Cases_Updated.xlsx` — ~99 test cases · TS_014, TS_020
- `CrossBrowser_Test_Cases_Updated.xlsx` — ~119 test cases · TS_016
- `MobileResponsive_Test_Cases_Updated.xlsx` — ~120 test cases · TS_017

#### 🔍 Testing Activities Completed
- Exploratory testing sessions across all 12 application modules
- Test scenario design (20 scenarios, P0/P1 prioritised)
- Test case authoring for all modules (1,071+ test cases)
- Defect reporting initiated in Jira

---

## Version History Summary

| Version | Date | Phase | Key Milestone |
|---|---|---|---|
| 1.0.0 | 2026-03-07 | Phase 1 — Manual | Initial release — full test suite authored |
| 2.0.0 | TBD | Phase 2 — Automation | Selenium/Cypress framework + CI/CD |
| 3.0.0 | TBD | Phase 3 — API + Perf | Postman API suite + JMeter performance |

---

*Maintained by MH Lohith — DemoBlaze QA Testing Project*
