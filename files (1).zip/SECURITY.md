# 🔒 Security Policy

## Overview

This repository contains **QA test documentation** — test cases, test scenarios,
test plans, and related artefacts — for the DemoBlaze e-commerce web application.

There is **no application source code** in this repository. However, this policy
exists to handle responsible disclosure of any issues related to:

- Sensitive test data accidentally committed (credentials, personal data)
- Security observations identified during testing of the DemoBlaze application
- Any other security concerns related to this repository's contents

---

## Supported Scope

| Item | In Scope |
|---|---|
| Test documentation files (XLSX, DOCX, MD) | ✅ Yes |
| Security findings observed during DemoBlaze exploratory testing | ✅ Yes |
| Accidentally exposed credentials or personal data in commits | ✅ Yes |
| DemoBlaze application source code vulnerabilities | ❌ No — report to DemoBlaze directly |

---

## Reporting a Security Issue

**Please do not report security issues through public GitHub Issues.**

If you discover a security concern related to this repository (e.g., accidentally
committed credentials, exposed personal data), please:

1. **Do not** open a public GitHub Issue
2. Contact the maintainer directly via GitHub private message or email
3. Include a description of the issue, the affected file(s), and any suggested remediation

We will acknowledge receipt within **48 hours** and aim to resolve confirmed
issues within **7 days**.

---

## Test Data Notice

All test data used in this project (usernames, passwords, order details) is either:

- Fictitious sample data created specifically for testing
- Data created via the publicly accessible DemoBlaze signup flow

No real personal data, payment card numbers, or private credentials belong to
real individuals are stored in this repository.

---

## Security Testing Scope

As part of this QA project, **security testing is planned for Phase 2** and will
cover:

- Input validation — XSS and SQL injection probing via form fields
- Authentication security — session token handling, logout completeness
- CSRF vulnerability observations
- Tool: OWASP ZAP (planned)

Any security vulnerabilities discovered in the DemoBlaze application itself
during testing will be documented as defects and reported responsibly.

---

*DemoBlaze QA Testing Project — Maintained by MH Lohith — 2026*
