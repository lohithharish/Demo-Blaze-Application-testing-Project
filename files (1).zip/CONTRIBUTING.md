# 🤝 Contributing to DemoBlaze QA Testing Project

Thank you for your interest in contributing to this project! This repository is a
QA portfolio project for the DemoBlaze e-commerce application and welcomes
contributions that improve test coverage, fix documentation, or enhance the
overall quality of the test suite.

---

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How to Contribute](#how-to-contribute)
- [Reporting Issues](#reporting-issues)
- [Submitting Changes](#submitting-changes)
- [Test Case Contribution Guidelines](#test-case-contribution-guidelines)
- [Documentation Standards](#documentation-standards)
- [License Agreement](#license-agreement)

---

## Code of Conduct

By participating in this project, you agree to maintain a respectful and
professional environment. Be constructive, be kind, and focus on improving
quality for everyone.

---

## How to Contribute

### 1. Fork the Repository

```bash
# Fork via GitHub UI, then clone your fork
git clone https://github.com/YOUR-USERNAME/demoblaze-qa-testing.git
cd demoblaze-qa-testing
```

### 2. Create a Feature Branch

```bash
# Always branch from main
git checkout -b feature/your-contribution-description

# Examples:
git checkout -b feature/add-wishlist-test-cases
git checkout -b fix/correct-login-tc-expected-result
git checkout -b docs/update-readme-automation-section
```

### 3. Make Your Changes

Follow the guidelines in the sections below depending on what you are contributing.

### 4. Commit with a Clear Message

```bash
git add .
git commit -m "feat: add 15 boundary test cases for signup username field"

# Commit message prefixes:
# feat:     New test cases or new feature coverage
# fix:      Correction to existing test cases or documentation
# docs:     README, markdown, or documentation updates
# refactor: Restructuring without changing test intent
# chore:    Maintenance tasks (renaming, reorganising files)
```

### 5. Push and Open a Pull Request

```bash
git push origin feature/your-contribution-description
```

Then open a Pull Request on GitHub with:
- A clear title describing what you added or changed
- A brief description of **why** the change is needed
- Reference to any related issue (e.g., `Closes #12`)

---

## Reporting Issues

If you find a problem with an existing test case, incorrect expected result,
or a missing test scenario, please open a GitHub Issue with:

- **Title:** Short, specific description of the problem
- **Module:** Which module is affected (e.g., Cart, Login)
- **Test Case ID:** The specific TC ID if applicable
- **Current Behaviour:** What the test case currently says
- **Expected Behaviour:** What it should say
- **Suggested Fix:** Optional — your proposed correction

---

## Test Case Contribution Guidelines

When adding or modifying test cases in the XLSX files, follow these standards:

### Required Columns (All XLSX Test Case Files)

| Column | Description |
|---|---|
| Test Case ID | Unique ID — format: `TC_[MODULE]_[NUMBER]` e.g. `TC_LOGIN_064` |
| Test Scenario ID | Parent scenario reference e.g. `TS_002` |
| Test Case Title | One-line, action-oriented description |
| Preconditions | State the application must be in before execution |
| Test Steps | Numbered, atomic steps |
| Test Data | Specific input values used |
| Expected Result | Exact, observable, verifiable outcome |
| Actual Result | Leave blank until executed |
| Status | Leave blank until executed |

### Test Case Writing Rules

- **One verification per test case** — don't bundle multiple checks into one TC
- **Expected results must be specific** — "Login succeeds and username appears in navbar" not just "Login works"
- **Preconditions must be complete** — another tester should be able to reproduce from scratch
- **Negative tests must specify the exact error message** expected where possible
- **Priority tagging is mandatory** — P0 / P1 / P2 / P3

---

## Documentation Standards

When contributing to Markdown files (`.md`):

- Use proper heading hierarchy (`#`, `##`, `###`)
- All tables must have headers and aligned columns
- Requirement IDs must follow the established format (`FR-XX-XX`, `NFR-XX-XX`)
- Keep language professional and clear — this portfolio is reviewed by hiring teams at MNCs

---

## License Agreement

By submitting a contribution to this repository, you agree that your
contribution is made under the same **MIT License** that covers this project.
See [LICENSE](LICENSE) for full terms.

---

*Thank you for helping improve the quality of this project!*
